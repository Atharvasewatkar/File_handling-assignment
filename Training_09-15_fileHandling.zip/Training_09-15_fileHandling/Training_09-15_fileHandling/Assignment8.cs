﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Training_09_15_fileHandling
{
    internal class Assignment8
    {
        public static void execute()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            desktop = desktop + "\\file1.txt";
            Console.WriteLine(desktop);
            try
            {
                File.ReadAllLines(desktop);
            }
            catch
            {
                File.WriteAllText(desktop, " ");

            }

            ///1---add
            Console.WriteLine("enter text in file");
            string content = Console.ReadLine();
            String[] txt = File.ReadAllLines(desktop);
            bool flag = true;
            for (int i = 0; i < txt.Length; i++)
            {
                if (txt[i] == content)
                    flag = false;

            }
            if (flag)
                File.AppendAllText(desktop, "\r\n" + content);
            else
                Console.WriteLine("already present");

            //2--Search 
            String[] txt1 = File.ReadAllLines(desktop);
            Console.WriteLine("enter text for search");
            string serchValue = Console.ReadLine().ToLower();
            bool ispresent = false;
            for (int i = 0; i < txt1.Length; i++)
            {
                if (txt1[i] == serchValue)
                    ispresent = true;
            }
            if (ispresent)
                Console.WriteLine("serached value is present");

            //3--.list All
            String[] txt2 = File.ReadAllLines(desktop);
            Console.WriteLine("list of texts");
            foreach (string s in txt2)
            {
                Console.WriteLine(s);
            }

            //4--Flex search
            String[] txt3 = File.ReadAllLines(desktop);
            Console.WriteLine("enter the text to be search");
            string check = Console.ReadLine().ToLower().Trim();
            bool isContains = false;
            for (int i = 0; i < txt3.Length; i++)
            {
                if (txt3[i]==check)
                {
                    isContains = true;
                }

            }
            if (isContains)
                Console.WriteLine($"{check} is persent ");


            Console.ReadLine();
        }
    }
}
    
