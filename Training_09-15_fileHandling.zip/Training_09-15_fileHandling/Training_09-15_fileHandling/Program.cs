﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Training_09_15_fileHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Assignment8.execute();

        }
    }
}
